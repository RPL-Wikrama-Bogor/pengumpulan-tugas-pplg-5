const  testFunction = () => {
    console.log('saya berasan dari test function')
}
const newFunction = (param) => {
    console.log(param)
}
module.exports = {testFunction, newFunction};