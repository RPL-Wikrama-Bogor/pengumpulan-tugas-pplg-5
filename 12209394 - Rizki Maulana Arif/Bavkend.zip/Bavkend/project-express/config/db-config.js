module.exports = {
    multipleStatement: true,
    database: 'db_express_wikrama',
    host: 'localhost',
    user: 'root',
    password:'',
}      