<template>
    <div class="card-service">
        <img src="@/assets/img/layanan.png" alt="layanan">
        <h4>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. At ut repellat blanditiis!
        </h4>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.alias sepe minimal</p>
    </div>
</template>

<style scoped>
    .card-service {
        text-align: start;
        min-height: 306px;
        padding: 30px 30px 0 30px;
        box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.05);
        border-radius: 60px 0px 0px 0px;
        background: white;
        transition: all 0.5s ease;
        margin: 10px 10px;
    }

    .card-service img {
        width: 100px;
    }

    .card-service h4{
        font-size: 10px;
        line-height: 30px;
        color: #343b4e;
    }

    .card-service p {
        font-weight: 400;
        color: #827f8d;
        margin: 0 0 10px 0;
    }


</style>